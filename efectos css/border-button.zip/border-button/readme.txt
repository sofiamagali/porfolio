This template / effect / code has been created by Tobias Reich.
You can customize and check it out on its original site on the following link:
https://codepen.io/electerious/pen/qPjbGm

Thank you
This template / effect / code has been created by Giana.
You can customize and check it out on its original site on the following link:
https://codepen.io/giana/pen/xdXpJB

Thank you
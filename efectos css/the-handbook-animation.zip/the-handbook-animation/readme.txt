This template / effect / code has been created by Yancy Min.
You can customize and check it out on its original site on the following link:
https://codepen.io/yancy/pen/Epbmxo

Thank you
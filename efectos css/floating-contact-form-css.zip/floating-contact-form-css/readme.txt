This template / effect / code has been created by Shante Austin.
You can customize and check it out on its original site on the following link:
https://codepen.io/shantedenise/pen/GYyxWV

Thank you
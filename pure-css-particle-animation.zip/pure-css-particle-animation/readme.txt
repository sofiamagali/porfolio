This template / effect / code has been created by Takeshi Kano.
You can customize and check it out on its original site on the following link:
https://codepen.io/tonkotsuboy/pen/zJbKNN

Thank you